from abc import ABC, abstractmethod


class FetchBankListUseCaseInterface(ABC):

    @abstractmethod
    def execute(self) -> None:
        raise NotImplementedError("Method not inmplemented")
