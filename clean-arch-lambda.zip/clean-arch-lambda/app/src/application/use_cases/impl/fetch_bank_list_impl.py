from app.src.application.client.interface.authorization_client_interface import (
    AuthorizationClientInterface,
)
from app.src.application.client.interface.bank_client_interface import (
    BankClientInterface,
)
from app.src.application.client.interface.secret_client_interface import (
    SecretClientInterface,
)
from app.src.application.client.interface.storage_client_interface import (
    StorageClientInterface,
)
from app.src.application.use_cases.interface.fetch_bank_list_interface import (
    FetchBankListUseCaseInterface,
)

from app.src.domain.logging.interface.logger_interface import LoggerInterface


class FetchBankListUseCaseImpl(FetchBankListUseCaseInterface):

    def __init__(
        self,
        logger: LoggerInterface,
        secret_client: SecretClientInterface,
        authorization_client: AuthorizationClientInterface,
        bank_client: BankClientInterface,
        storage_client: StorageClientInterface,
    ):
        self.__logger = logger
        self.__secret_client = secret_client
        self.__authorization_client = authorization_client
        self.__bank_client = bank_client
        self.__storage_client = storage_client

    def execute(self, correlation_id: str, flow_id: str) -> None:
        secret_dto = self.__secret_client.get_secret()
        token_dto = self.__authorization_client.get_token(secret_dto)

        list_bank_dto = self.__bank_client.list_banks(
            token_dto, correlation_id, flow_id
        )

        self.__storage_client.save_data(list_bank_dto)
