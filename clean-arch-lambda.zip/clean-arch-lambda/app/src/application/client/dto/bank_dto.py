from dataclasses import dataclass


@dataclass
class BankDTO:
    code: str
    name: str
    ispb: str
    cnpj: str
