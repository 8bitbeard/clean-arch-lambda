from dataclasses import dataclass


@dataclass
class SecretDTO:
    client_id: str
    client_secret: str
