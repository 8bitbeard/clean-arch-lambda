from abc import abstractmethod


class SecretClientInterface:

    @abstractmethod
    def get_secret(self) -> None:
        raise NotImplementedError("Method not implemented")
