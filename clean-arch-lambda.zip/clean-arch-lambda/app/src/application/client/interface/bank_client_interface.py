from abc import ABC, abstractmethod
from typing import List

from app.src.application.client.dto.bank_dto import BankDTO
from app.src.application.client.dto.token_dto import TokenDTO


class BankClientInterface(ABC):

    @abstractmethod
    def list_banks(
        self, token: TokenDTO, app_id: str, correlation_id: str, flow_id: str
    ) -> List[BankDTO]:
        raise NotImplementedError("Method not implemented")
