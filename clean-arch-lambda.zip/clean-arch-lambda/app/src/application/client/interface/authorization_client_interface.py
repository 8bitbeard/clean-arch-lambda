from abc import ABC, abstractmethod
from app.src.application.client.dto.secret_dto import SecretDTO
from app.src.application.client.dto.token_dto import TokenDTO


class AuthorizationClientInterface(ABC):

    @abstractmethod
    def get_token(self, secret: SecretDTO) -> TokenDTO:
        raise NotImplementedError("Method not implemented")
