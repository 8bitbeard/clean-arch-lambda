from abc import ABC, abstractmethod
from typing import List

from app.src.application.client.dto.bank_dto import BankDTO


class StorageClientInterface(ABC):

    @abstractmethod
    def save_data(self, data: List[BankDTO]) -> None:
        raise NotImplementedError("Method not implemented")
