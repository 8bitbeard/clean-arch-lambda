from pydantic import BaseModel


class MetadataModel(BaseModel):
    date: str
