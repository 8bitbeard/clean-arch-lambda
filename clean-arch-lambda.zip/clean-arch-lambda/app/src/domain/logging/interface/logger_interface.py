from abc import ABC, abstractmethod


class LoggerInterface(ABC):

    @abstractmethod
    def info() -> None:
        raise NotImplemented("Method not implemented")

    @abstractmethod
    def debug() -> None:
        raise NotImplemented("Method not implemented")

    @abstractmethod
    def error() -> None:
        raise NotImplemented("Method not implemented")
