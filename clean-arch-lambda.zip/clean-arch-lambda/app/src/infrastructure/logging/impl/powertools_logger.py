from app.src.domain.logging.interface.logger_interface import LoggerInterface


class PowertoolsLogger(LoggerInterface):

    def __init__(self):
        super().__init__()

    def info():
        pass

    def debug():
        pass

    def error():
        pass
