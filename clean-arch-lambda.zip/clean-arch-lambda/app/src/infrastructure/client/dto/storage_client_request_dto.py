import datetime
from pydantic import BaseModel, Field


class CustomConfigBaseModel(BaseModel):
    class Config:
        populate_by_name = True


class MetadataDTO(CustomConfigBaseModel):
    date: str = Field(default_factory=datetime.now, alias="data")


class BankItemDTO(CustomConfigBaseModel):
    id: str = Field(..., alias="codigo")
    name: str = Field(..., alias="nome")
    ispb: str = Field(..., alias="ispb")


class StorageClientRequestDTO(CustomConfigBaseModel):
    metadata: MetadataDTO = Field(..., alias="metadados")
    items: BankItemDTO = Field(..., alias="itens")
