from app.src.application.client.interface.storage_client_interface import (
    StorageClientInterface,
)
from app.src.domain.logging.interface.logger_interface import LoggerInterface


class StorageClientImpl(StorageClientInterface):
    def __init__(self, logger: LoggerInterface):
        self.__logger = logger

    def save_data(self, data: List[Bank]):
        raise NotImplementedError
