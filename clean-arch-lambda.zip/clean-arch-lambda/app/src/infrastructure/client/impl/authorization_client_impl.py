from app.src.application.client.dto.secret_dto import SecretDTO
from app.src.application.client.dto.token_dto import TokenDTO
from app.src.application.client.interface.authorization_client_interface import (
    AuthorizationClientInterface,
)
from app.src.domain.logging.interface.logger_interface import LoggerInterface


class AuthorizationClientImpl(AuthorizationClientInterface):
    def __init__(self, logger: LoggerInterface):
        self.__logger = logger

    def get_token(self, secret: SecretDTO) -> TokenDTO:
        pass
