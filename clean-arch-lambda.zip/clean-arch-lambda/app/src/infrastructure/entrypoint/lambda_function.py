from app.src.application.use_cases.impl.fetch_bank_list_impl import FetchBankListUseCaseImpl
from app.src.infrastructure.client.impl.authorization_client_impl import AuthorizationClientImpl
from app.src.infrastructure.client.impl.bank_client_impl import BankClientImpl
from app.src.infrastructure.client.impl.secret_client_impl import SecretClientImpl
from app.src.infrastructure.client.impl.storage_client_impl import StorageClientImpl
from app.src.infrastructure.logging.impl.powertools_logger import PowertoolsLogger


logger = PowertoolsLogger()


def inject_dependencies():
    secret_client = SecretClientImpl(logger)
    authorization_client = AuthorizationClientImpl(logger)
    bank_client = BankClientImpl(logger)
    storage_client = StorageClientImpl(logger)
    
    return FetchBankListUseCaseImpl(logger, secret_client, authorization_client, bank_client, storage_client)


def lambda_handler(event, context):

    fetch_bank_list_use_case = inject_dependencies()
    pass
